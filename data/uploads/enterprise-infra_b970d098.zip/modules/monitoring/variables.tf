variable "prefix" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "tags" { type = map(string) }
variable "retention_days" { type = number; default = 30 }
variable "enable_container_insights" { type = bool; default = true }
