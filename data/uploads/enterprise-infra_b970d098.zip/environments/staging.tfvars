environment    = "staging"
location       = "eastus"
naming_prefix  = "mc-staging"
