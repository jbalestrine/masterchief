environment    = "prod"
location       = "eastus"
naming_prefix  = "mc-prod"
