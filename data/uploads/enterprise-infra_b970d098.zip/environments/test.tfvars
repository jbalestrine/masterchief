environment    = "test"
location       = "eastus"
naming_prefix  = "mc-test"
