environment    = "dev"
location       = "eastus"
naming_prefix  = "mc-dev"
