# Outputs

output "keyvault_uri" { value = module.keyvault.key_vault_uri }
output "log_analytics_workspace_id" { value = module.monitoring.workspace_id }
