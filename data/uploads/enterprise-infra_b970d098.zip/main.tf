# Main module composition

module "monitoring" {
  source              = "./modules/monitoring"
  prefix              = local.prefix
  location            = local.location
  resource_group_name = module.hub.hub_rg_name
  tags                = local.tags
}

module "keyvault" {
  source              = "./modules/keyvault"
  prefix              = local.prefix
  location            = local.location
  resource_group_name = module.hub.hub_rg_name
  tags                = local.tags
}
