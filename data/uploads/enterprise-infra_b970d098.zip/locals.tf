locals {
  prefix      = var.naming_prefix
  environment = var.environment
  location    = var.location
  tags        = var.tags
  hub_rg_name = "${local.prefix}-hub-rg"
}
