variable "subscription_id" {
  type        = string
  description = "Azure Subscription ID"
  default     = ""
}

variable "tenant_id" {
  type        = string
  description = "Azure AD Tenant ID"
  default     = ""
}

variable "environment" {
  type        = string
  description = "Environment name (dev/test/staging/prod)"
  default     = "dev"
}

variable "location" {
  type        = string
  description = "Azure region"
  default     = "eastus"
}

variable "naming_prefix" {
  type        = string
  description = "Naming prefix for all resources"
  default     = "mc"
}

variable "tags" {
  type = map(string)
  default = {
    Environment = "dev"
    ManagedBy   = "terraform"
    Project     = "masterchief"
  }
}
