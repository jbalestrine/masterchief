# HashiCorp Vault Module

Auto-generated DevOps Suite module for `hvac`.

## Installation

```bash
pip install hvac
```

Then upload `hvac.zip` via the Module Manager UI.

## Selected Features

- **Auth Cubbyhole** (`hvac.Client.auth_cubbyhole`) — Perform a login request with a wrapped token.
- **Is Authenticated** (`hvac.Client.is_authenticated`) — Helper method which returns the authentication status of the client
- **Lookup Token** (`hvac.Client.lookup_token`) — GET /auth/token/lookup/<token>
- **Renew Token** (`hvac.Client.renew_token`) — POST /auth/token/renew
- **Revoke Token** (`hvac.Client.revoke_token`) — POST /auth/token/revoke
- **Write** (`hvac.Client.write`) — POST /<path>
- **Write Data** (`hvac.Client.write_data`) — Write data to a path. Similar to write() without restrictions on data keys.
- **Get Policy** (`hvac.Client.get_policy`) — Retrieve the policy body for the named policy.
- **List** (`hvac.Client.list`) — GET /<path>?list=true
- **Read** (`hvac.Client.read`) — GET /<path>
- **Login** (`hvac.Client.login`) — Perform a login request.
- **Logout** (`hvac.Client.logout`) — Clears the token used for authentication, optionally revoking it before doing so.
- **Delete** (`hvac.Client.delete`) — DELETE /<path>

## Files

| File | Purpose |
|------|---------|
| `plugin.py` | Data fetcher — implements `get_data()` |
| `template.html` | Jinja2 UI for the dashboard card |
| `requirements.txt` | Pip dependencies |
| `README.md` | This file |

## Usage

Once installed, navigate to the dashboard and enable the **HashiCorp Vault** module
using the sidebar toggle. The module will load its UI automatically.

## Customization

Edit `plugin.py` to add authentication, environment variables, or
custom data transformations. Edit `template.html` to change the UI layout.

---
*Generated 2026-02-21 by DevOps Suite Module Generator*
