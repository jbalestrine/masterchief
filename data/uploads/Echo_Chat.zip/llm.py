import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_PATH = "models/your_model.gguf"

def get_llm():
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    return model, tokenizer
