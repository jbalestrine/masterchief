from chat_bot import ChatBot

def main():
    bot = ChatBot()
    print("Echo Chat is ready! Type 'exit' to quit.\n")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Goodbye!")
            break
        response = bot.chat(user_input)
        print(f"Echo: {response}")

if __name__ == "__main__":
    main()
