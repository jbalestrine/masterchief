from llm import get_llm

class ChatBot:
    def __init__(self):
        self.model, self.tokenizer = get_llm()

    def chat(self, prompt: str, max_length=512):
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        outputs = self.model.generate(**inputs, max_new_tokens=max_length)
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return response
