# Echo Chat

## Setup

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Place your `.gguf` model in the `models/` folder.

3. Run the chat:

```bash
python main.py
```
