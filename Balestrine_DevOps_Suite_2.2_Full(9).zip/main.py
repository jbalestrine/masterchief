# Entry point
from core import bootstrap
from gui import launch_gui

if __name__ == '__main__':
    bootstrap()
    launch_gui()