# GUI Placeholder
print("GUI launching...")