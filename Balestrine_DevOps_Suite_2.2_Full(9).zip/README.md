# Balestrine DevOps Suite 2.2

Full Edition - Manual Install

## How to Run

Use `start.sh` on Linux/macOS or `start.bat` on Windows to begin.